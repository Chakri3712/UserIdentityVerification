package com.userverification.resetportal.service;

import com.userverification.resetportal.config.PingOneConfig;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
public class IdentityService {

    private final PingOneConfig pingOneConfig;

    public IdentityService(PingOneConfig pingOneConfig) {
        this.pingOneConfig = pingOneConfig;
    }

    // Step 1: Verify User
    public ResponseEntity<String> verifyUser(Map<String, String> request) {
        String username = request.get("username");
        return ResponseEntity.ok("Verification started for " + username);
    }

    // Step 2: Trigger MFA Challenge
    public ResponseEntity<String> triggerMfa(Map<String, String> request) {
        String userId = request.get("userId");
        return ResponseEntity.ok("MFA challenge sent to " + userId);
    }

    // Step 3: Handle MFA Response
    public ResponseEntity<String> handleMfaResponse(Map<String, String> response) {
        String status = response.get("status");
        if ("SUCCESS".equalsIgnoreCase(status)) {
            return ResponseEntity.ok("Password reset link sent!");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Verification failed");
        }
    }

    // Step 4: Example PingOne Token Call
    public ResponseEntity<String> getAccessToken() {
        RestTemplate restTemplate = new RestTemplate();

        // Prepare request body
        Map<String, String> requestBody = new HashMap<>();
        requestBody.put("grant_type", "client_credentials");
        requestBody.put("client_id", pingOneConfig.getClientId());
        requestBody.put("client_secret", pingOneConfig.getClientSecret());

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        HttpEntity<Map<String, String>> entity = new HttpEntity<>(requestBody, headers);

        // Call PingOne token endpoint
        ResponseEntity<String> response = restTemplate.postForEntity(
                pingOneConfig.getTokenEndpoint(),
                entity,
                String.class
        );

        return response;
    }
}
