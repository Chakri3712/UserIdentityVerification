package com.userverification.resetportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserVerificationSolutionApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserVerificationSolutionApplication.class, args);
	}

}
