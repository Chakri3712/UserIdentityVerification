package com.userverification.resetportal.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:3001")
public class IdentityController {
	
    @PostMapping("/verifyUser")
    public ResponseEntity<String> verifyUser(@RequestBody Map<String, String> request) {
        String username = request.get("username");
        return ResponseEntity.ok("Verification started for " + username);
    }

    @PostMapping("/mfa/challenge")
    public ResponseEntity<String> triggerMfa(@RequestBody Map<String, String> request) {
        String userId = request.get("userId");
        return ResponseEntity.ok("MFA challenge sent to " + userId);
    }

    @PostMapping("/mfa/response")
    public ResponseEntity<String> mfaResponse(@RequestBody Map<String, String> response) {
        String status = response.get("status");
        if ("SUCCESS".equalsIgnoreCase(status)) {
            return ResponseEntity.ok("Password reset link sent!");
        } else {
            return ResponseEntity.status(401).body("Verification failed");
        }
    }
}
