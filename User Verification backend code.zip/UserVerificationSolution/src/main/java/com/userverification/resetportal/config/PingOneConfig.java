package com.userverification.resetportal.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PingOneConfig {

    @Value("${pingone.client-id}")
    private String clientId;

    @Value("${pingone.client-secret}")
    private String clientSecret;

    @Value("${pingone.auth-endpoint}")
    private String authEndpoint;

    @Value("${pingone.token-endpoint}")
    private String tokenEndpoint;

    @Value("${pingone.mfa-endpoint}")
    private String mfaEndpoint;

    // Getters
    public String getClientId() { return clientId; }
    public String getClientSecret() { return clientSecret; }
    public String getAuthEndpoint() { return authEndpoint; }
    public String getTokenEndpoint() { return tokenEndpoint; }
    public String getMfaEndpoint() { return mfaEndpoint; }
}
